
import boto3
import json
import datetime


# define a function to write a string to s3
def write_to_s3(bucket, key, data):
    s3 = boto3.resource('s3')
    s3.Object(bucket, key).put(Body=data)


# define a function to generate the CSV string
def generate_csv_string(face_detail):
    csv_string = ""
    for key, value in face_detail.items():
        csv_string += f"\"{value}\","
    csv_string = csv_string[:-1]
    return csv_string

def generate_face_detail_dict():
  """Generates a dictionary of face detail names."""
  face_detail_names = [
      "age_low",
      "age_high",
      "emotion_1_value",
      "emotion_2_value",
      "gender",
      "smile",
      "eyeglasses",
      "beard",
      "mustache",
      "upload_time"
  ]
  face_detail_dict = {}
  for i, name in enumerate(face_detail_names):
    face_detail_dict[i] = name
  return face_detail_dict

def generate_face_detail_string(face_detail_dict):
  """Generates a face detail string from a dictionary of face detail names, with double quotes around each name."""
  face_detail_string = ""
  for i in range(len(face_detail_dict)):
    face_detail_string += "\"" + face_detail_dict[i] + "\""
    if i < len(face_detail_dict) - 1:
      face_detail_string += ","
  return face_detail_string
  

# define a function to detect faces
def detect_faces(photo, bucket):
    client = boto3.client('rekognition')
    response = client.detect_faces(Image={'S3Object': {'Bucket': bucket, 'Name': photo}},
                                   Attributes=['ALL'])

    now = datetime.datetime.now()

    # Convert the datetime object to a string in the desired format
    current_date_time = now.strftime("%Y-%m-%d-%H-%M-%S")

    # Print the current date time
    print(current_date_time)

    file_name = current_date_time + ".csv"

    print('Detected faces for ' + photo)

    # initialize face_detail with the new header line
    face_detail_dict = generate_face_detail_dict()
    face_detail = generate_face_detail_string(face_detail_dict)   
    face_detail = face_detail + "\n"
    date = datetime.datetime.now()
    data_values = date.strftime("%Y-%m-%d %H:%M:%S.%f")

    # print current datetime
    print(data_values)

    for faceDetail in response['FaceDetails']:
        # create a face_detail dictionary for the current face
        face_detail_dict = {
            "age_low": faceDetail['AgeRange']['Low'],
            "age_high": faceDetail['AgeRange']['High'],
            "emotion_1": faceDetail['Emotions'][0]['Type'],
            "emotion_2": faceDetail['Emotions'][1]['Type'],
            "gender": faceDetail['Gender']['Value'],
            "smile": faceDetail['Smile']['Value'],
            "eyeglasses": faceDetail['Eyeglasses']['Value'],
            "beard": faceDetail['Beard']['Value'],
            "mustache": faceDetail['Mustache']['Value'],
            "upload_time": data_values
        }

        # append the face_detail dictionary to the face_detail string
        face_detail += generate_csv_string(face_detail_dict) + "\n"

        print('The detected face is between ' + str(faceDetail['AgeRange']['Low'])
              + ' and ' + str(faceDetail['AgeRange']['High']) + ' years old')

        print("face detail:" + face_detail)

        Key = f'txt/{current_date_time}.csv'
        write_to_s3(bucket, Key, face_detail)

    return len(response['FaceDetails'])


# define the lambda handler function
def lambda_handler(event, context):
    # put your bucket here
    bucket = 'image-reko-2023-10'

    # put your key here(file )
    photo = '2023-ncnu.jpg'

    face_count = detect_faces(photo, bucket)
    print("Faces detected: " + str(face_count))

    return {
        'statusCode': 200,
        'body': json.dumps('Face Reko Success!')
    }